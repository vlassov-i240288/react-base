import "../../App.css";
import "../../components/MessageList/messageList.css";
import { useEffect, useState, useCallback } from "react";
import { MessageList } from "../../components/MessageList/messageList";
import { Form } from "../../components/Form/form";
import { AUTHORS } from "../../constants";
import FolderList from "../../components/ChatList/ChatList";
import { useParams } from "react-router-dom";

const initialChats = {
    chat1: {
      messages: [{ text: "Dummy", author: AUTHORS.human, id: "chat1-1" }],
      name: "Chat 1",
      id: "chat1",
    },
    chat2: {
      name: "Chat 2",
      id: "chat2",
      messages: [
        { text: "this is chat 2", author: AUTHORS.human, id: "chat2-1" },
      ],
    },
    chat3: { name: "Chat 3", id: "chat3", messages: [] },
  };

function Chats() {
  const heading = "Чат REACT";
//   const [messages, setMessages] = useState([]);

  const { chatId } = useParams();
  console.log(chatId);
  const [chats, setChats] = useState(initialChats);
  

//   const handleSendMessage = useCallback(
//     (newMessage) => {
//       setMessages([...messages, newMessage]);
//       console.log(newMessage);
//     },
//     [messages]
//   );
const handleSendMessage = useCallback(
    (newMessage) => {
      // setMessages([...messages, newMessage]);
      setChats({
        ...chats,
        [chatId]: {
          ...chats[chatId],
          messages: [...chats[chatId].messages, newMessage],
        },
      });
    },
    [chats, chatId]
  );

  useEffect(() => {
    if (
    //   !messages.length ||
    //   messages[messages.length - 1].author === AUTHORS.robot
    !chatId ||
      !chats[chatId]?.messages.length ||
        chats[chatId].messages[chats[chatId].messages.length - 1].author ===
          AUTHORS.robot
    ) {
      return;
    }

    const timeout = setTimeout(() => {
      const newMessage = {
        text: "Я робот!",
        author: AUTHORS.robot,
        id: Date.now(),
      };

      handleSendMessage(newMessage);
    }, 1000);

    //   setMessages([...messages, newMessage]);
    // }, 1500);

//     return () => clearTimeout(timeout);
//   }, [messages]);
return () => clearTimeout(timeout);
  }, [chats]);

  return (
    <div className="App-header">
      
      <div className="container">
      
        <div className="Heading">
          <h1>{ heading }</h1>
        </div>

        <div className="header__center">
        
          <div className="header__left">
            <Form onSendMessage={handleSendMessage} />    
            <FolderList chats={chats}/>
          </div>
        {!!chatId && (
            <div className="header__right">
            <div className="MessageList">
              <MessageList messages={chats[chatId].messages} />
            </div>
          </div>
        )

        }
          

        </div>
      </div>
        
        
    </div>
    
  );
}

export default Chats;