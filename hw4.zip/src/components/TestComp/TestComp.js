import React from 'react';

function Test(props) {
    return <h1>Hello, {props.name}</h1>;
  }

export default Test;