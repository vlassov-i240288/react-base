

export const Profile = ({ match }) => {
  console.log(match);
  return <h2>THIS IS PROFILE</h2>;
};

export default Profile;