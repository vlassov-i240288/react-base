export const AUTHORS = {
  human: "Я",
  robot: "БОТ",
};
