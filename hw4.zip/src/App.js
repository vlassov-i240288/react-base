import Routes from "./components/Routes/Routes";


function App() {
  return (
    <Routes />
  )
}

export default App;
